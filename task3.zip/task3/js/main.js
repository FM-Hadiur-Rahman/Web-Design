$(document).ready(function(){
    $('#primary-menu').slicknav({
prependTo:'.responsive_menu'
});
    $('.progress-box').circleProgress({
     value: 0.25,
    size: 80,
    fill: {
      gradient: ["#f857a0", "#ff585b"]
    },
         lineCap: 'round',
        emptyFill:'#fff'
        
  }).on('circle-animation-progress', function(event, progress) {
    $(this).find('strong').html(Math.round(25 * progress) + '<i>%</i>');
  });
    
    $('.progress-box1').circleProgress({
     value: 0.50,
    size: 80,
    fill: {
      gradient: ["#f857a0", "#ff585b"]
    },
         lineCap: 'round',
        emptyFill:'#fff'
        
  }).on('circle-animation-progress', function(event, progress) {
    $(this).find('strong').html(Math.round(50 * progress) + '<i>%</i>');
  });
    
     $('.progress-box2').circleProgress({
     value: 0.75,
    size: 80,
    fill: {
      gradient: ["#f857a0", "#ff585b"]
    },
         lineCap: 'round',
        emptyFill:'#fff'
        
  }).on('circle-animation-progress', function(event, progress) {
    $(this).find('strong').html(Math.round(75 * progress) + '<i>%</i>');
  });
    
    
     $('.progress-box3').circleProgress({
     value: 1,
    size: 80,
    fill: {
      gradient: ["#f857a0", "#ff585b"]
    },
         lineCap: 'round',
        emptyFill:'#fff'
        
  }).on('circle-animation-progress', function(event, progress) {
    $(this).find('strong').html(Math.round(100 * progress) + '<i>%</i>');
  });
    
    
    jQuery('#primary-menu').meanmenu();
    
    
    
    
       $(".full-carosel-box").owlCarousel({
            autoplay:true,
            loop:true,
             nav:true,
            dots:false,
          navText:['<i class="fa fa-arrow-left"></i>','<i class="fa fa-arrow-right"></i>'],
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:3
                },
                1000:{
                    items:3
                }
            }
        });
    
    
     $("").owlCarousel({
            autoplay:true,
            loop:true,
             nav:true,
            dots:false,
      
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:5
                },
                1000:{
                    items:5
                }
            }
        });
    
    
    
   
    
     
    
    $(".search-btn li a").on("click",function(){
$(".search-button").addClass("active");
return false;
});
$(".close-button").on("click", function(){
$(".search-button").removeClass("active");
return false;
});
    
    
    
    jQuery(window).on('scroll', function() {
if ($(this).scrollTop() > 1) {
$('.header-pa').addClass("sticky");
} else {
$('.header-pa').removeClass("sticky");
}
});
    });


